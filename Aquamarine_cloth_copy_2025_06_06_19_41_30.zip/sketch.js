let arvore;
let jardineiro;
let machados = [];
let velocidadeMachado = 3;
let contagemMachados = 0;
let gameOver = false;

function setup() {
  createCanvas(600, 400);
  arvore = new Arvore(width / 2, height / 2);
  jardineiro = new Jardineiro(mouseX, mouseY);
  // Inicializa o primeiro machado
  machados.push(new Machado(random(width), random(height)));
}

function draw() {
  background(220);

  if (gameOver) {
    displayGameOver();
    return;
  }

  // Atualizar e exibir a árvore
  arvore.display();

  // Atualizar e exibir o jardineiro
  jardineiro.update();
  jardineiro.display();

  // Verificar e atualizar os machados
  for (let i = machados.length - 1; i >= 0; i--) {
    let m = machados[i];
    m.update();
    m.display();

    // Checar se o jardineiro tocou no machado
    if (jardineiro.hits(m)) {
      machados.splice(i, 1); // Remove o machado da lista
      machados.push(new Machado(random(width), random(height))); // Adiciona um novo machado em outra direção
    }

    // Checar se o machado atingiu a árvore
    if (m.hits(arvore)) {
      contagemMachados++;
      machados.splice(i, 1); // Remove o machado
      machados.push(new Machado(random(width), random(height))); // Adiciona um novo machado em outra direção
    }
  }

  // Verifica se o jogo acabou
  if (contagemMachados >= 3) {
    gameOver = true;
  }
}

function displayGameOver() {
  textSize(32);
  textAlign(CENTER, CENTER);
  fill(255, 0, 0); // Cor vermelha para o texto de Game Over
  if (contagemMachados >= 3) {
    text("Você Perdeu!", width / 2, height / 2);
  } else {
    text("Você Ganhou!", width / 2, height / 2);
  }
}

class Arvore {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.radius = 30;
  }

  display() {
    textSize(32);
    textAlign(CENTER, CENTER);
    fill(0);
    text("🌳", this.x, this.y); // Emoji da árvore
  }
}

class Jardineiro {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.radius = 20;
  }

  update() {
    // A posição do jardineiro é controlada pelo mouse
    this.x = mouseX;
    this.y = mouseY;
  }

  display() {
    textSize(32);
    textAlign(CENTER, CENTER);
    fill(0);
    text("👨‍🌾", this.x, this.y); // Emoji do jardineiro
  }

  hits(m) {
    // Verifica se o jardineiro encostou no machado
    let d = dist(this.x, this.y, m.x, m.y);
    return d < this.radius + m.radius;
  }
}

class Machado {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.radius = 15;
    this.speed = createVector(random(-1, 1), random(-1, 1));
    this.speed.setMag(velocidadeMachado); // Define a velocidade do machado
  }

  update() {
    this.x += this.speed.x;
    this.y += this.speed.y;

    // Se o machado sair da tela, ele aparece de volta do lado oposto
    if (this.x < 0) this.x = width;
    if (this.x > width) this.x = 0;
    if (this.y < 0) this.y = height;
    if (this.y > height) this.y = 0;
  }

  display() {
    textSize(32);
    textAlign(CENTER, CENTER);
    fill(0);
    text("🪓", this.x, this.y); // Emoji do machado
  }

  hits(arvore) {
    // Verifica se o machado atingiu a árvore
    let d = dist(this.x, this.y, arvore.x, arvore.y);
    return d < this.radius + arvore.radius;
  }
}
